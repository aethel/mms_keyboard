"use strict";

(function () {
  var keyboardButton = document.querySelectorAll('#virtualKeyboard .kbButton');


  console.log(keyboardButton);
})();