"use strict";

(function () {
var designSection = document.querySelector('.theme-personalisation');
  InitSlider(designSection, 950);
})();
